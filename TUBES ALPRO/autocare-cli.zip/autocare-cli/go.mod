module autocare

go 1.26.2

require github.com/aquasecurity/table v1.11.0

require (
	github.com/mattn/go-runewidth v0.0.13 // indirect
	github.com/rivo/uniseg v0.2.0 // indirect
	golang.org/x/sys v0.0.0-20210615035016-665e8c7367d1 // indirect
	golang.org/x/term v0.0.0-20220526004731-065cf7ba2467 // indirect
)
